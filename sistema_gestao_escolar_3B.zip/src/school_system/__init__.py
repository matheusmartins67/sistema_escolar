"""Pacote principal do Sistema de Gestão Escolar."""

